
/**
 * 目前只支持alias以及externals属性
 * alias要使用唯一性标记，建议以bundle为标记
 * @type {{alias: {}, externals: []}}
 */
module.exports = {
    alias: {},
    externals: []
}
