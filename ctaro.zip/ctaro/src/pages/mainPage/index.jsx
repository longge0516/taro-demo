import React from 'react'

export default class Index extends React.Component {
  componentDidMount () {
  }
  render () {
    return null
  }
}
