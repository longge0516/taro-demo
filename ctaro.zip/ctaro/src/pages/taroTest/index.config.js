export default {
  navigationBarTitleText: '首页',
  usingComponents: {
    'claim-coupon': './components/claimCoupon/claimCoupon' // 书写第三方组件的相对路径
  }
}
